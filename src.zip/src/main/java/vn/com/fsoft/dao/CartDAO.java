package vn.com.fsoft.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vn.com.fsoft.model.Admin;
import vn.com.fsoft.model.Bill;
import vn.com.fsoft.model.Cart;
import vn.com.fsoft.model.Shirt;
import vn.com.fsoft.util.HibernateUtil;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CartDAO {
	Session session = null;
	
	@SuppressWarnings("unchecked")
	public ArrayList<Cart> getList(int bid){
		session = HibernateUtil.getSessionFactory().openSession();
        String sql = "From Cart c where c.billId='"+bid+"'";
        Query query = session.createQuery(sql);
        
        ArrayList<Cart> list =  (ArrayList<Cart>)query.list();
        session.close();
        if (list.size() > 0) {
            return list;
        }
        return null;
	}
	
	
	public void insertCart(Cart c) {
		session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
        session.save(c);
        tx.commit();
        session.close();
	}
	public String md5p(String s) {
		String p = "";
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("MD5");
			md.update(s.getBytes());
			BigInteger bigInteger = new BigInteger(1, md.digest());
			p = bigInteger.toString(16);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return p;
	}
	@SuppressWarnings("unchecked")
	public int nextID () {
		session = HibernateUtil.getSessionFactory().openSession();
        String sql = "From Bill b";
        Query query = session.createQuery(sql);
        
        ArrayList<Bill> list =  (ArrayList<Bill>)query.list();
        session.close();
        if (list.size() > 0) {
    		Bill b = list.get(list.size() - 1);
    		int next = b.getId();
            return next;
        }
        return 0;
	}
}
