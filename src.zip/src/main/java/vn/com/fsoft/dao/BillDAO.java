package vn.com.fsoft.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vn.com.fsoft.model.Admin;
import vn.com.fsoft.model.Bill;
import vn.com.fsoft.model.Cart;
import vn.com.fsoft.model.Shirt;
import vn.com.fsoft.util.HibernateUtil;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class BillDAO {
	Session session = null;
	
	@SuppressWarnings("unchecked")
	public ArrayList<Bill> getList(String uid){
		session = HibernateUtil.getSessionFactory().openSession();
        String sql = "From Bill b where b.userId='"+uid+"'";
        Query query = session.createQuery(sql);
        
        ArrayList<Bill> list =  (ArrayList<Bill>)query.list();
        session.close();
        if (list.size() > 0) {
            return list;
        }
        return null;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<Bill> getFilteredBillList(int uid, String els, String stt, String sor, String ord) {
		session = HibernateUtil.getSessionFactory().openSession();
        String sql = "From Bill b where b.userId = '"+uid+"'";
        if (!els.equals("")) {
        	sql = sql + " and b.receiverName like '%"+els+"%'";
        }
        if (!stt.equals("2")) {
        	sql = sql + " and b.paymentStatus = "+stt;
        }
        sql = sql + " order by b." + sor + " " + ord;
        Query query = session.createQuery(sql);

        ArrayList<Bill> list =  (ArrayList<Bill>)query.list();
        session.close();
        if (list.size() > 0) {
            return list;
        }
        return null;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<Cart> getSelectedCartList(String bid){
		session = HibernateUtil.getSessionFactory().openSession();
        String sql = "From Cart c where c.billId='"+bid+"'";
        Query query = session.createQuery(sql);
        
        ArrayList<Cart> list =  (ArrayList<Cart>)query.list();
        session.close();
        if (list.size() > 0) {
            return list;
        }
        return null;
	}
	
	@SuppressWarnings("unchecked")
	public String getShirtName(String sid){
		session = HibernateUtil.getSessionFactory().openSession();
        String sql = "From Shirt s where s.id='"+sid+"'";
        Query query = session.createQuery(sql);
        
        ArrayList<Shirt> list =  (ArrayList<Shirt>)query.list();
        Shirt s = list.get(0);
        session.close();
        if (s != null) {
            return s.getName();
        }
        return null;
	}
	@SuppressWarnings("unchecked")
	public void insertBill(int id,int userid, String receiverName, String receiverPhone, String receiverAddress, int totalPrice) {
		session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Date d = new Date();
        String start = new SimpleDateFormat("yyyy-MM-dd").format(d);
        Bill b = null;
        if(userid!=0) {
        	b = new Bill(id, start, userid, receiverName, receiverPhone, receiverAddress, totalPrice, false);
        }else {
        	b = new Bill(id, start, receiverName, receiverPhone, receiverAddress, totalPrice, false);
        }
		
		session.save(b);
        tx.commit();
        session.close();
	}
	public String md5p(String s) {
		String p = "";
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("MD5");
			md.update(s.getBytes());
			BigInteger bigInteger = new BigInteger(1, md.digest());
			p = bigInteger.toString(16);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return p;
	}
	@SuppressWarnings("unchecked")
	public int nextID () {
		session = HibernateUtil.getSessionFactory().openSession();
        String sql = "From Bill b";
        Query query = session.createQuery(sql);
        
        ArrayList<Bill> list =  (ArrayList<Bill>)query.list();
        session.close();
        if (list.size() > 0) {
    		Bill b = list.get(list.size() - 1);
    		int next = b.getId()+1;
            return next;
        }
        return 0;
	}
}
