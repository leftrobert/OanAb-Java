package vn.com.fsoft.controller;

import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import vn.com.fsoft.dao.BillDAO;
import vn.com.fsoft.dao.CartDAO;
import vn.com.fsoft.dao.ShirtDAO;
import vn.com.fsoft.model.Cart;
import vn.com.fsoft.model.User;

@Controller
public class BillController{
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/addBill", method=RequestMethod.POST)
	public String handlingBill(HttpServletRequest arg0, HttpServletResponse arg1m,RedirectAttributes redirectAttributes,@RequestParam("name") String name,@RequestParam("phone") String phone,@RequestParam("address") String address, HttpSession session){
		// TODO Auto-generated method stub
		User u = null;
		if (session.getAttribute("loggedin") != null) {
			u = (User)session.getAttribute("loggedin");
		}
		BillDAO billDao = new BillDAO();
		CartDAO cartDao = new CartDAO();
		
		ArrayList<Cart> cartlist= new ArrayList<Cart>();
		if(session.getAttribute("cart") !=null) {
			cartlist= (ArrayList<Cart>)session.getAttribute("cart");
			//String id,String userid, String ReceiverName, String ReceiverPhone, String ReceiverAddress, String TotalPrice
			int id = billDao.nextID();
			int uid=0;
			if(u!=null) uid= u.getId();
			int totalPrice = 0;
			for(Cart c: cartlist){
				totalPrice += c.getPrice();
			}
			if(uid!=0) {
				totalPrice *=0.95;
			}
			billDao.insertBill(id, uid, name, phone, address, totalPrice);
			for(Cart c: cartlist){
				c.setBillId(id);
				cartDao.insertCart(c);
			}
			session.removeAttribute("cart");
		}
		
//		int a = Integer.parseInt(amount);
//		ShirtDAO sdao = new ShirtDAO();
//		if (session.getAttribute("cart") == null) {
//			cartlist = new ArrayList<Cart>();
//		} else {
//			cartlist = (ArrayList<Cart>)session.getAttribute("cart");
//		}
//		for (Cart c0: cartlist) {
//			if (c0.getShirtId().equals(shirtid) && c0.getSize().equals(size) && c0.getColor().equals(color)) {
//				c0.setAmount(c0.getAmount() + a);
//				c0.setPrice(c0.getAmount() * sdao.getShirt(shirtid).getPrice());
//				session.setAttribute("cart", cartlist);
//				return "redirect:cart";
//			}
//		}
//		Cart c = new Cart();
//		c.setShirtId(shirtid);
//		c.setSize(size);
//		c.setColor(color);
//		c.setAmount(a);
//		c.setPrice(a * sdao.getShirt(shirtid).getPrice());
//		cartlist.add(c);
//		session.setAttribute("cart", cartlist);
		return "redirect:cart";
	}

	
}
