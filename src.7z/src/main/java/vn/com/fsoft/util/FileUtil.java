package vn.com.fsoft.util;

import javax.servlet.http.Part;

public class FileUtil {
	public static String getFileName(final Part part ){
		final String partHeader = part.getHeader("content-disposition");
		for(String content : partHeader.split(";")){
			if(content.trim().startsWith("filename")){
				return content.substring(content.indexOf("=")+1).trim().replace("\"", "");
			}
		}
		return null;
	}
}
